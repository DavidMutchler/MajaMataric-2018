//servo(which port you want activated, what measure of degrees in ticks)
    //servo(1, 76)
    //servo(0, 668)
    //servo(2, 1999)
    //servo(3, 2047)
//447 + 452 
//389 + 786
//DATE_ARM's starting position = 2047
//DATE_ARM's position for wiping of dates = 1618
//DATE_ARM's position for manuvering through PVC pipe = 791